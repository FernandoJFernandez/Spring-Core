package com.app.ioc;

public class Bisturi implements Utensilios {

	public void usar() {
		System.out.println("Usando Bistur�");
		
	}
}
