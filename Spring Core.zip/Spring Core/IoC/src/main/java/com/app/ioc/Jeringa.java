package com.app.ioc;

public class Jeringa  implements Utensilios {

	public void usar() {
		System.out.println("Usando Jeringa");
		
	}

}
