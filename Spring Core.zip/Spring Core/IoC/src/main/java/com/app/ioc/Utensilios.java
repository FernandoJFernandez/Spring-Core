package com.app.ioc;

public interface Utensilios {
	public void usar();
}
